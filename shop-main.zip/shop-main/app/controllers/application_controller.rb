# frozen_string_literal: true

class ApplicationController < ActionController::Base
  include Pagy::Backend

  before_action :set_locale
  before_action :configure_permitted_parameters, if: :devise_controller?

  protect_from_forgery with: :exception

  protected

  def configure_permitted_parameters
    devise_parameter_sanitizer.permit(:sign_up) do |u|
      u.permit(:name, :email, :password, :phone, :address, :city, :state, :pincode)
    end
    devise_parameter_sanitizer.permit(:account_update) do |u|
      u.permit(:name, :email, :password, :current_password, :phone, :address)
    end
  end

  private

  def set_locale
    I18n.locale = params[:locale] || I18n.default_locale
    puts I18n.locale
    # puts '----'
  end

  def default_url_options(_options = {})
    { locale: I18n.locale }
  end
end
