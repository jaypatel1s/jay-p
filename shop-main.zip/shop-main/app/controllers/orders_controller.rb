# frozen_string_literal: true

class OrdersController < ApplicationController
  before_action :authenticate_user!
  before_action :set_order, only: %i[show edit update destroy]

  def index
    @orders = current_user.orders
  end

  def show
    @order = Order.find(params[:id])
    @order_products = @order.order_products
  end

  def new
    @order = Order.new
  end

  def create
    return unless current_user.carts.present? && (@order = current_user.orders.new(order_params))
    return unless @order.save

    current_user.carts.each do |cart|
      next if cart.blank?

      @order.order_products.create(
        product_id: cart.product_id,
        selling_price: cart.product.selling_price,
        discount: cart.product.discount,
        quantity: cart.quantity,
        mrp: cart.product.mrp,
        total_price: current_user.total_price,
        discount_type: cart.product.discount_type
      )
      current_user.carts.all.destroy_all
    end
    redirect_to(@order, notice: t('.notice'), allow_other_host: true)
  end

  def destroy
    @order.destroy
    redirect_to orders_path, notice: t('.notice')
  end

  private

  def set_order
    @order = Order.find(params[:id])
    return if @order.present?

    redirect_to root_path, notice: 'Order not found'
  end

  def order_params
    params.permit(:sub_total, :payment_type, :payment_method, :status)
  end
end
