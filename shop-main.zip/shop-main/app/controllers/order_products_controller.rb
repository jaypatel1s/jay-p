# frozen_string_literal: true

class OrderProductsController < ApplicationController
  before_action :authenticate_user!

  private

  def order_params
    params.require(:order_product).permit(:quantity, :mrp, :selling_price, :discount, :discount_type, :total_price)
  end
end
