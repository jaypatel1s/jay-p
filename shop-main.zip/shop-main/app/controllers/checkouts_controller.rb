# frozen_string_literal: true

class CheckoutsController < ApplicationController
  before_action :authenticate_user!

  def index
    @user = current_user.address if current_user.present?
  end
end
