# frozen_string_literal: true

class HomeController < ApplicationController
  before_action :authenticate_user!, except: %i[index about contact]
  def index; end

  def contact; end

  def about; end
end
