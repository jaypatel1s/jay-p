# frozen_string_literal: true

class ProductsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_product, only: %i[show edit update destroy]

  def index
    @pagy, @products = pagy(Product.all)
    @products = Product.order('created_at DESC')
    @categories = Category.all

    @products = @products.where(category: params[:category]) if params[:category].present?

    @categories = Product.distinct.pluck(:category_id)

    return unless params[:search]

    @products = Product.where('name LIKE ? ',
                              "%#{params[:search]}%")
  end

  def show
    @product = Product.find(params[:id])
  end

  private

  def set_product
    @product = Product.find(params[:id])
  end

  def product_params
    params.require(:product).permit(:name, :desc, :image, :mrp, :selling_price, :discount, :discount_type,
                                    :category, :search)
  end
end
