# frozen_string_literal: true

class CartsController < ApplicationController
  before_action :authenticate_user!

  before_action :set_cart, only: %i[update destroy]

  def index
    @carts = current_user.carts
  end

  def new
    @cart = Cart.new
  end

  def create
    @cart = Cart.find_or_initialize_by(user_id: cart_params[:user_id], product_id: cart_params[:product_id])
    if @cart.persisted?
      @cart.quantity += cart_params[:quantity].to_i
    else
      @cart.quantity = cart_params[:quantity].to_i
    end

    return unless @cart.save

    redirect_to products_path, notice: t('.notice')
  end

  def update
    @cart.update(cart_params)
    redirect_to cart_path, notice: t('.notice')
  end

  def destroy
    @cart.destroy
    params[:id] = nil
    redirect_to cart_path, notice: t('.notice')
  end

  private

  def set_cart
    @cart = current_user.carts.find(params[:id])
  end

  def cart_params
    params.permit(:user_id, :product_id, :quantity)
  end
end
