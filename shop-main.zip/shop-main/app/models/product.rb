# frozen_string_literal: true

class Product < ApplicationRecord
  belongs_to :category
  has_many :order_products, dependent: :destroy
  has_many :orders, through: :order_products

  validates :name, :desc, :image, :mrp, :selling_price, :discount, :discount_type,
            :category, presence: true

  has_many :carts
  has_one_attached :image do |attachable|
    attachable.variant :image, resize_to_limit: [100, 100]
  end
end
