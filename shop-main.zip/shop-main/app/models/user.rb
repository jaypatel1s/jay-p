# frozen_string_literal: true

class User < ApplicationRecord
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable, :confirmable
  has_many :orders, dependent: :destroy
  has_many :carts
  validates :email, uniqueness: true, presence: true
  validates :phone, uniqueness: true
  validates :phone, length: { is: 10 }, numericality: { only_integer: true }

  def sub_total
    total = 0
    carts.each do |cart|
      total += cart.product.mrp.to_f * cart.quantity.to_f
    end
    total
  end

  def cart_discount
    tot_discount = 0
    carts.each do |cart|
      tot_discount += cart.product.discount.to_f * cart.quantity.to_f
    end
    tot_discount
  end

  def total_price
    sub_total - cart_discount
  end
end
