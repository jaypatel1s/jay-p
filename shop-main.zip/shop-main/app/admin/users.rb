# frozen_string_literal: true

ActiveAdmin.register User do
  # See permitted parameters documentation:
  # https://github.com/activeadmin/activeadmin/blob/master/docs/2-resource-customization.md#setting-up-strong-parameters
  #
  # Uncomment all parameters which should be permitted for assignment
  #

  actions :all, except: :new
  actions :all, except: :destroy

  permit_params :name, :phone, :address, :state, :city, :pincode, :email, :encrypted_password, :reset_password_token,
                :reset_password_sent_at, :remember_created_at

  config.batch_actions = false
  index do
    column :id
    column :name
    column :email
    actions
  end

  #
  # or
  #
  # permit_params do
  #   permitted = [:name, :phone, :address, :state, :city, :pincode, :email, :encrypted_password, :reset_password_token, :reset_password_sent_at, :remember_created_at]
  #   permitted << :other if params[:action] == 'create' && current_user.admin?
  #   permitted
  # end
end
