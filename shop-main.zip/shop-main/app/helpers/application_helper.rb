# frozen_string_literal: true

module ApplicationHelper
  include Pagy::Frontend
end
