# frozen_string_literal: true

class CreateOrderProducts < ActiveRecord::Migration[7.0]
  def change
    create_table :order_products do |t|
      t.decimal :mrp
      t.integer :quantity
      t.decimal :selling_price
      t.string :discount
      t.string :discount_type
      t.decimal :total_price
      t.references :order, null: false, foreign_key: true
      t.references :product, null: false, foreign_key: true

      t.timestamps
    end
  end
end
