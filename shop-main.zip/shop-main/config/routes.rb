# frozen_string_literal: true

Rails.application.routes.draw do
  scope '(locales)', locale: /en|gu/ do
    devise_for :admin_users, ActiveAdmin::Devise.config
    ActiveAdmin.routes(self)
    devise_for :users,
               controllers: { sessions: 'devise/sessions', registrations: 'devise/registrations', passwords: 'devise/passwords', confirmations: 'devise/confirmations' }, path: '', path_names: { sign_in: 'login', sign_out: 'logout', password: 'forget', confirmation: 'verification', unlock: 'unblock', sign_up: 'signup' }

    devise_scope :user do
      get 'signup', to: 'users/registrations#create'
      get 'forget', to: 'devise/passwords#new'
      get 'logout', to: 'users/sessions#destroy'
    end

    # Defines the root path route ("/")
    get 'home', to: 'home#index'

    get 'about', to: 'home#about'
    get 'contact', to: 'home#contact'
    get 'search', to: 'products#search'
    get 'category', to: 'products#category'
    get 'products', to: 'products#index'
    get 'products/:id', to: 'products#show', as: 'product'
    get 'carts', to: 'carts#index', as: 'cart'
    post 'carts', to: 'carts#create', as: 'cart_create'
    put 'carts/:id', to: 'carts#update', as: 'cart_update'
    delete 'carts/:id', to: 'carts#destroy', as: 'cart_destroy'
    get 'checkout', to: 'checkouts#index', as: 'checkout'

    resources :orders, only: %i[index show create destroy]
    resources :order_products, only: %i[create update destroy]

    root to: 'home#index'
  end
end
