# frozen_string_literal: true

if Rails.env.development?
  ActiveRecordQueryTrace.enabled = true
  ActiveRecordQueryTrace.lines = 5

  ActiveRecordQueryTrace.level = :custom
  require 'rails/backtrace_cleaner'
  ActiveRecordQueryTrace.backtrace_cleaner = Rails::BacktraceCleaner.new.tap do |bc|
    bc.remove_filters!
    bc.remove_silencers!
    bc.add_silencer do |line|
      line =~ /\b(active_record_query_trace|rake-13.0.1|active_support|active_record|irb|bootsnap|spring|rails|thor|rubygems|ruby-2.7.2|active_model)\b/
    end
  end
end
